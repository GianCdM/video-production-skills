import React from "react";
import { AbsoluteFill, Audio, staticFile, Sequence, interpolate, useCurrentFrame, useVideoConfig } from "remotion";
import {
  SEGMENTS,
  FPS,
  FADE_FRAMES,
  FADE_DURATION_SEC,
  INTRO_DURATION_SEC,
  OUTRO_DURATION_SEC,
  segmentDurationFrames,
} from "../data/segments";
import { TitleCard } from "../components/TitleCard";
import { TestimonialSegment } from "../components/TestimonialSegment";

export const HomenagemPaga: React.FC = () => {
  const introFrames = INTRO_DURATION_SEC * FPS;
  const outroFrames = OUTRO_DURATION_SEC * FPS;
  const { durationInFrames } = useVideoConfig();
  const frame = useCurrentFrame();

  // Calculate segment start frames (dip-to-black: no overlap)
  let currentFrame = introFrames;
  const segmentStarts: number[] = [];
  for (const seg of SEGMENTS) {
    segmentStarts.push(currentFrame);
    currentFrame += segmentDurationFrames(seg);
  }
  const outroStart = currentFrame;

  // Music starts 1.3s after outro begins (after title animation)
  const musicStart = outroStart + Math.round(FPS * 1.3);

  return (
    <AbsoluteFill style={{ backgroundColor: "#000" }}>
      {/* INTRO TITLE CARD */}
      <Sequence from={0} durationInFrames={introFrames}>
        <TitleCard
          title="Valeu, Paga!"
          subtitle="Multicategorias agradece  ·  iFood"
          variant="intro"
        />
      </Sequence>

      {/* ALL TESTIMONIAL SEGMENTS — dip-to-black (no overlap) */}
      {SEGMENTS.map((segment, index) => {
        const segFrames = segmentDurationFrames(segment);
        const segStart = segmentStarts[index];

        return (
          <Sequence
            key={`seg-${index}`}
            from={segStart}
            durationInFrames={segFrames}
          >
            <DipToBlackWrapper durationInFrames={segFrames}>
              <TestimonialSegment segment={segment} />
            </DipToBlackWrapper>
          </Sequence>
        );
      })}

      {/* OUTRO TITLE CARD */}
      <Sequence from={outroStart} durationInFrames={outroFrames}>
        <TitleCard
          title="Voa, Paga! 🚀"
          subtitle="Boa sorte nos novos desafios!  ·  iFood"
          variant="outro"
        />
      </Sequence>

      {/* Background music */}
      <Sequence from={musicStart}>
        <Audio
          src={staticFile("Voa-Paga.mp3")}
          volume={0.3}
        />
      </Sequence>
    </AbsoluteFill>
  );
};

/** Wraps a segment with fade-in and fade-out (dip-to-black) */
const DipToBlackWrapper: React.FC<{
  children: React.ReactNode;
  durationInFrames: number;
}> = ({ children, durationInFrames }) => {
  const frame = useCurrentFrame();

  const opacity = interpolate(
    frame,
    [0, FADE_FRAMES, durationInFrames - FADE_FRAMES, durationInFrames],
    [0, 1, 1, 0],
    {
      extrapolateLeft: "clamp",
      extrapolateRight: "clamp",
    }
  );

  // Audio volume follows the same curve — prevents voice bleeding
  const volume = interpolate(
    frame,
    [0, FADE_FRAMES, durationInFrames - FADE_FRAMES, durationInFrames],
    [0, 1, 1, 0],
    {
      extrapolateLeft: "clamp",
      extrapolateRight: "clamp",
    }
  );

  return (
    <AbsoluteFill style={{ opacity }}>
      {/* Volume is controlled via CSS opacity on the video element +
          the audio fade is handled by the opacity of the container.
          Since OffthreadVideo respects the container opacity for both
          video and audio in Remotion, this creates a true dip-to-black. */}
      {children}
    </AbsoluteFill>
  );
};
