#!/bin/bash
# Setup script for remotion-paga project
# Run this once after cloning: bash setup.sh

set -e

cd "$(dirname "$0")"

echo "==> Installing npm dependencies..."
npm install

echo "==> Creating symlinks to video files in public/..."
VIDEO_DIR="../"

# List of all video files referenced by the project
FILES=(
  "Gian-Paga-cfr.mp4"
  "Marcelo-Paga-cfr.mp4"
  "Lucas Pessoa-Paga-cfr.mp4"
  "Eli-Paga-cfr.mp4"
  "Aline_Paga-cfr.mp4"
  "Debora-Paga-cfr.mp4"
  "Marta-Paga-cfr.mp4"
  "giu-paga-cfr.mp4"
  "Edu-Paga-cfr.mp4"
  "Natalia-Paga-cfr.mp4"
  "Renan-Paga-cfr.mp4"
)

for f in "${FILES[@]}"; do
  if [ -f "${VIDEO_DIR}${f}" ]; then
    ln -sf "../../${f}" "public/${f}"
    echo "   Linked: ${f}"
  else
    echo "   WARNING: ${VIDEO_DIR}${f} not found, skipping"
  fi
done

echo ""
echo "==> Setup complete! Run 'npm start' to open Remotion Studio."
echo "    NOTE: If Voa-Paga.mp3 exists, place it in public/Voa-Paga.mp3"
